from PIL import Image
import numpy as np
import os
from skimage import io
join = os.path.join
import torch
from segment_anything import sam_model_registry
from segment_anything.utils.transforms import ResizeLongestSide
from skimage import transform
from segment.yolox import YOLOX
import warnings
import cv2

# Ignore warnings
warnings.filterwarnings("ignore", category=UserWarning)

# Configuration
ts_img_path = './data/test_in/'
model_type = 'vit_b'
checkpoint = './pretrained_model/tonguesam.pth'
device = 'cuda:3'
path_out = './data/mytest_out/'
segment = YOLOX()

# Load model
sam_model = sam_model_registry[model_type](checkpoint=checkpoint).to(device)
sam_model.eval()

# Create output directory if it doesn't exist
os.makedirs(path_out, exist_ok=True)

for f in os.listdir(ts_img_path):
    if not f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
        continue
        
    try:
        with torch.no_grad():
            # Read and preprocess image
            image_path = join(ts_img_path, f)
            image_data = io.imread(image_path)
            
            # Handle different image formats
            if len(image_data.shape) == 2:  # Grayscale
                image_data = np.repeat(image_data[:, :, None], 3, axis=-1)
            elif image_data.shape[-1] > 3:  # RGBA or other
                image_data = image_data[:, :, :3]
            
            # Normalize image
            lower_bound, upper_bound = np.percentile(image_data, 0.5), np.percentile(image_data, 99.5)
            image_data_pre = np.clip(image_data, lower_bound, upper_bound)
            image_data_pre = (image_data_pre - np.min(image_data_pre)) / (np.max(image_data_pre) - np.min(image_data_pre)) * 255.0
            image_data_pre[image_data == 0] = 0
            image_data_pre = transform.resize(image_data_pre, (400, 400), order=3, 
                                           preserve_range=True, mode='constant', 
                                           anti_aliasing=True)
            image_data_pre = np.uint8(image_data_pre)
            
            # Get image embedding
            sam_transform = ResizeLongestSide(sam_model.image_encoder.img_size)
            resize_img = sam_transform.apply_image(image_data_pre)
            resize_img_tensor = torch.as_tensor(resize_img.transpose(2, 0, 1)).to(device)
            input_image = sam_model.preprocess(resize_img_tensor[None, :, :, :])
            ts_img_embedding = sam_model.image_encoder(input_image)

            # Get bounding box prompt
            boxes = segment.get_prompt(image_data_pre)
            
            if boxes is not None:
                sam_trans = ResizeLongestSide(sam_model.image_encoder.img_size)
                box = sam_trans.apply_boxes(boxes, (400, 400))
                box_torch = torch.as_tensor(box, dtype=torch.float, device=device)
            else:
                box_torch = None

            # Get mask prediction
            sparse_embeddings, dense_embeddings = sam_model.prompt_encoder(
                points=None,
                boxes=box_torch,
                masks=None,
            )
            
            medsam_seg_prob, _ = sam_model.mask_decoder(
                image_embeddings=ts_img_embedding.to(device),
                image_pe=sam_model.prompt_encoder.get_dense_pe(),
                sparse_prompt_embeddings=sparse_embeddings,
                dense_prompt_embeddings=dense_embeddings,
                multimask_output=False,
            )
            
            # Post-process mask
            medsam_seg_prob = medsam_seg_prob.cpu().detach().numpy().squeeze()
            medsam_seg = (medsam_seg_prob > 0.5).astype(np.uint8)
            
            # Resize mask to original image size (400x400)
            medsam_seg = cv2.resize(medsam_seg, (400, 400), interpolation=cv2.INTER_NEAREST)
            
            # Create output with original colors for tongue and black background
            output_image = np.zeros_like(image_data_pre)  # Initialize with black background
            output_image[medsam_seg == 1] = image_data_pre[medsam_seg == 1]  # Keep original colors for tongue
            
            # Save result
            output_path = join(path_out, os.path.splitext(f)[0] + '.png')
            Image.fromarray(output_image).save(output_path)
            print(f"Successfully processed: {f}")
            
    except Exception as e:
        print(f"Error processing {f}: {str(e)}")
        continue